WILD! Healing 2026 — Brochure for Adobe Illustrator (editable, font-matched)
============================================================================
5 SVG files = the 5 brochure pages (A4). Text is EDITABLE type (not outlines)
and now MATCHES the design, because the exact fonts are included.

STEP 1 — INSTALL THE FONTS (important, do this first):
  Open the /fonts folder and install all 8 .ttf files
  (macOS: select all > double-click > Install Fonts. Windows: right-click > Install).
  These are custom static weights named "WH Fraunces…", "WH Spectral…", "WH Hanken…".
  (The standard Google variable fonts default to a heavy weight and won't match —
   that's why these specific instances are bundled.)

STEP 2 — OPEN IN ILLUSTRATOR:
  File > Open each WILD-Healing-brochure-pN.svg. The type is fully editable in the
  bundled fonts; photos are embedded; page size is A4 (210 x 297 mm).

Fonts are SIL Open Font License (derived from Fraunces, Spectral, Hanken Grotesk
on Google Fonts) — see the OFL-*.txt files. Free to install, embed, and share.
