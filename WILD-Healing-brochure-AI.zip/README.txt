WILD! Healing 2026 — Brochure (Illustrator-editable SVG)
========================================================
5 SVG files = the 5 brochure pages (A4). Open each in Adobe Illustrator
(File > Open). All text comes in as EDITABLE type objects — not outlines.

BEFORE EDITING: install the three brand fonts so the type displays correctly
(Fraunces, Spectral, Hanken Grotesk — all free, in the fonts pack):
  https://wildgala.com/wild-healing-fonts.zip

Notes:
- Photos are embedded in the SVGs (self-contained, nothing to relink).
- Each line of body copy is its own type object (from the page layout), so
  you edit line-by-line rather than as a reflowing paragraph.
- Page size is A4 (210 x 297 mm).
