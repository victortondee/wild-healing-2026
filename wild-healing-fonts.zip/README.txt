WILD! Healing 2026 — Brand Fonts
================================

Three typefaces (all open-source, SIL Open Font License — free to use, install,
embed, and share). Each folder includes the font files and its OFL.txt license.

1. Fraunces  — Display & headlines (the WILD! Healing wordmark, titles).
   Variable font: Fraunces[...].ttf (upright) + Fraunces-Italic[...].ttf.
   Use weights 300 (light, large) and 400; italic for quotes/sub-headlines.

2. Spectral  — Body copy & paragraphs.
   Static weights (ExtraLight…Bold + italics). Use Light (300) / Regular (400).

3. Hanken Grotesk — Labels, buttons, UI (eyebrows, dates, buttons — ALL CAPS).
   Variable font: HankenGrotesk[wght].ttf + italic. Use 600–700.

To install: double-click each .ttf (macOS Font Book / Windows "Install").
Variable fonts expose the full weight range in apps that support them.
Also available on Google Fonts: fonts.google.com
